from Game_outdated import Game

engine = Game()
engine.run()